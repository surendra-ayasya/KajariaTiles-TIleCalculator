import {createContext} from "react";

const TileInputsContext = createContext();

export default TileInputsContext;